﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Forms;
using System.IO;

namespace Projet_PlateformeNet
{
    public partial class Form1 : Form
    {
        private String[] header = new string[] { "ID", "Type", "Format", "Valeur", "Min", "Max" };
        private String[] header2 = new string[] { "Type", "Min", "Max" };

        /// <summary>
        /// Début exam
        /// </summary>
        private String[] header3 = new string[] { "Ref", "Date", "Type", "Description" };
        private String[] filter = new string[] { "Pas de filtre", "User", "ID", "Alarm" };
        private int[] countevent = new int[] { 1, 10, 100 };
        private BDD Db;
        /// <summary>
        /// Fin exam
        /// </summary>
       
        private DataConfig dc = new DataConfig();
        private GestionAlarme ga = new GestionAlarme();
        private Stack<Mesure> mesures = new Stack<Mesure>();
        private Random rnd = new Random();
        private Graphique graphique = new Graphique();
        private String file_title = "Dataze.csv";

        int mintemp ;
        int maxtemp ;

        int minhum ;
        int maxhum ;

        int minvent ;
        int maxvent ;

        int minpres ;
        int maxpres ;


        public Form1()
        {
            InitializeComponent();
            initdt();
            AddToGraph();
            initdt2();
            initdt3();
            initcb();
            
            
            initchart();
            timer1.Enabled = false;

        }

        

        /// <summary>
        /// Début éxamen
        /// </summary>
        private void initdt3()
        {
            dataGridView2.ColumnCount = 4;
            for (int i = 0; i < header3.Length; i++)
            {
                dataGridView2.Columns[i].HeaderCell.Value = header3[i];
            }
        }
        
        private void initcb()
        {
            for (int i = 0; i < countevent.Length; i++)
            {
                comboBox_event.Items.Add(countevent[i]);
            }

            comboBox_filter.Items.AddRange(filter);
        }

        /// <summary>
        /// Fin examen
        /// </summary>
        /// 

        private void AddToGraph()
        {
            foreach (string val in graphique.Series.Keys)
            {
                chart1.Series.Add(graphique.Series[val]);
            }
        }

        private void initchart()
        {
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "{00.00}";
            for (int i = 0; i < chart1.Series.Count; i++)
            {
                chart1.Series[i].MarkerStyle = (System.Windows.Forms.DataVisualization.Charting.MarkerStyle)MarkerStyle.Square;
                chart1.Series[i].MarkerSize = 5;
            }
        }

        private void initdt2()
        {
            DataTable dt = new DataTable();
            for (int i = 0; i < header2.Length ; i++)
            {
                dt.Columns.Add(header[i]);
            }
            dt.Rows.Add("Temperature", 80, 100);
            dt.Rows.Add("Vitesse du vent(km/h)", 70, 100);
            dt.Rows.Add("Humidité", 50, 100);
            dt.Rows.Add("Pression", 80, 100);
            dataGridView_alarme.DataSource = dt;
                
        }

        private void addMesure(Mesure mesure)
        {
            if (mesures.Count > 50)
            {
                mesures.Pop();
                mesures.Push(mesure);
            }
            else
            {
                mesures.Push(mesure);
            }
        }

        private void initdt()
        {
            dataGridView1.ColumnCount = 6;
            for (int i = 0; i < header.Length; i++)
            {
                
                dataGridView1.Columns[i].HeaderCell.Value = header[i];
                
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == false)
            {

                timer1.Enabled = true;
            }

            else if(timer1.Enabled == true)
            {
                timer1.Enabled = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int second = timer1.Interval/100;
            int random = rnd.Next(0, 4);
            Mesure mesure = new Mesure(dc.getcb_bits[random], dc.getcb_mesure[random], dc.Min, dc.Max);
            int value = rnd.Next(mesure.getmin, mesure.getmax);
            addMesure(mesure);
            dataGridView1.Rows.Insert(0, mesure.getID, mesure.getType, mesure.getformat, value, mesure.getmin, mesure.getmax);
            ///PlacerPoints(mesure,second,random);

            if(dataGridView1.Rows[0].Cells[1].Value == "Température")
            {
                if(value < maxtemp && value > mintemp)
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Red;
                }
                else
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Green;
                }
            }

            if (dataGridView1.Rows[0].Cells[1].Value == "Humidité")
            {
                if (value < this.maxhum && value > this.minhum )
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Red;
                }
                else
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Green;
                }
            }

            if (dataGridView1.Rows[0].Cells[1].Value == "Vent")
            {
                if (value < maxvent && value > minvent)
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Red;
                }
                else if (!(value < this.maxvent && value > this.minvent))
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Green;
                }

            }

            if (dataGridView1.Rows[0].Cells[1].Value == "Pression")
            {
                if (value < this.maxpres && value > this.minpres)
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Red;
                }
                else if (!(value < this.maxpres && value > this.minpres))
                {
                    dataGridView1.Rows[0].Cells[3].Style.BackColor = Color.Green;
                }
            }

            ///Début examen
            ///
            
            Db = new BDD();
            Db.insertEvent(DateTime.Now.ToString(), "ID","Un ID de type "+mesure.getType+" inséré");
        
           
            //fin



        }

        private void PlacerPoints(Mesure mesure, int second, int random)
        {
            graphique.Series[mesure.getType].Points.AddXY(second, random);
        }

        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(timer1.Enabled == true)
            {
                timer1.Enabled = false;
            }
            
            dc = new DataConfig();
            dc.ShowDialog();

            
            
        }

        private void configurerLesAlarmesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                timer1.Enabled = false;
            }
            ga = new GestionAlarme();
            ga.ShowDialog();
            this.maxhum = ga.getmaxhum;
            this.minhum = ga.getminhum;

            this.maxtemp = ga.getmaxtemp;
            this.mintemp = ga.getmintemp;

            this.maxvent = ga.getmaxvent;
            this.minvent = ga.getminvent;

            this.maxpres = ga.getmaxpres;
            this.minpres = ga.getminpres;

            
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Début éxamen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void créerUnProfilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 fn = new Form2();
            fn.ShowDialog();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            int count = Int32.Parse(comboBox_event.Text);
            String filter = comboBox_filter.Text;
          

            Db = new BDD();
            Db.Selecting(filter,null,dataGridView2) ;


        }

        private void button_create_Click(object sender, EventArgs e)
        {
            
            if(File.Exists(file_title) == false)
            {
                File.Create(file_title);
            }

            for (int i = 0; i < dataGridView2.RowCount; i++)
            {
                String line = (dataGridView2.Rows[i].Cells[0].Value + ";" + dataGridView2.Rows[i].Cells[1].Value + ";" + dataGridView2.Rows[i].Cells[2].Value + ";" + dataGridView2.Rows[i].Cells[3].Value);
                File.AppendAllText(file_title, line + Environment.NewLine);
            }
            MessageBox.Show("Insertion réussie");
            //Fihier dispo dans /bin/Debug !


            ///Fin examen
        }

        
    }
   }
        
        
    

