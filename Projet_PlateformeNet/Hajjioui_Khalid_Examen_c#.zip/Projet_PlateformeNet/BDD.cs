﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet_PlateformeNet
{
    /// <summary>
    /// Début éxamen
    /// </summary>
    class BDD
    {
        String chemin = "Provider=Microsoft.ACE.Oledb.12.0; Data Source=DB_Logs.accdb;";
        OleDbConnection connexion;

        public void connectDb()
        {
            this.connexion = new OleDbConnection(chemin);
            this.connexion.Open();
        }

        public void insertEvent(String date,String type,String description)
        {
            this.connectDb();
            String insert = "INSERT INTO LogsTable (LogDate,LogType,LogDescription) VALUES (' " + date + "','" + type + "','" + description + "')";
            OleDbCommand query = new OleDbCommand();
            query.CommandText = insert;
            query.Connection = this.connexion;
            query.ExecuteNonQuery();
            MessageBox.Show("Inséré avec succès");
            this.connexion.Close();
            
        }

        public void Selecting(String filter,String value,DataGridView data)
        {
            String select;
            List<String> date = new List<string>();
            List<String> Type = new List<string>();
            List<String> description = new List<string>();
            List<int> reference = new List<int>();

            this.connectDb();
            if(filter == "" || filter == "Pas de filtre")
            {
                select = "SELECT * FROM LogsTable";
            }
            else
            {
                select = "SELECT * FROM LogsTable WHERE LogType = '" + filter + "'";
            }
             
            OleDbCommand query = new OleDbCommand();
            
            query.Connection = this.connexion;
            query.CommandText = select;
            OleDbDataReader cursor = query.ExecuteReader(); 
            while(cursor.Read())
            {
                reference.Add((int)cursor["LogRef"]);
                date.Add((String)cursor["LogDate"]);
                Type.Add((String)cursor["LogType"]);
                description.Add((String)cursor["LogDescription"]);

            }
            data.RowCount = date.Count;
            ///Commme les listes ont le meme count, on aurait pu prendre nimporte laquel
            for (int i = 0; i < date.Count; i++)
            {
                
                data.Rows[i].Cells[0].Value = reference[i];
                data.Rows[i].Cells[1].Value = date[i];
                data.Rows[i].Cells[2].Value = Type[i];
                data.Rows[i].Cells[3].Value = description[i];
            }
            this.connexion.Close();
            }

        }

        



    }

